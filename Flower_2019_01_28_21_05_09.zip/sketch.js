var a=0;
var i=0;
var slider;
function setup() {
  createCanvas(400, 400);
  slider=createSlider(1,30,1);
}

function draw() 
{
 colorMode(HSB);
 background(i%255,250,250);
 stroke(i%255,250,250);
 flower();
 i++;
}
	function flower()
	{
	translate(200,200);
  beginShape();
	colorMode(RGB);
	fill(255);
	strokeWeight(2);
  var k=slider.value();
	for(a=0;a<=2*PI;a+=0.01)
	{
		var r=150*cos(k*a);
		var x=r*cos(a);
		var y=r*sin(a);
		vertex(x,y);
	}
	endShape();
}