var drops=[];
class drop
{
  constructor()
  {
    this.x=random(width);
    this.y=random(-200,-100);
    this.yspeed=random(2,10);
    this.len=random(1,10);
  }
  fall()
  {
    this.y=this.y +this.yspeed;
    if(this.y>600)
    {
      this.y=random(-200,-100);
    }
  }
  show(i)
  {
    colorMode(HSB);
    strokeWeight(4);
    stroke(200);
    ellipse(this.x,this.y,1,10);
  }
}
    
function setup() {
  createCanvas(600, 600);
  for(var i=0;i<200;i++)
  {
    drops[i]=new drop();
  }
}

function draw() {
  colorMode(HSB);
  background(255,25,1000);
  Rainbow();
   for(var i=0;i<200;i++)
  {
    drops[i].fall();
    drops[i].show(i);
  }
}
function Rainbow()
{
  colorMode(RGB);
  strokeWeight(6);
  noFill();
  stroke(255,0,0);
  arc(300,700,800,800,PI,2*PI);
  stroke(255,165,0);
  arc(300,700,810,810,PI,2*PI);
  stroke(255,255,0);
  arc(300,700,820,820,PI,2*PI);
  stroke(0,255,0);
  arc(300,700,830,830,PI,2*PI);
  stroke(0,0,255);
  arc(300,700,840,840,PI,2*PI);
  stroke(75,0,130);
  arc(300,700,850,850,PI,2*PI);
  stroke(148,0,211);
  arc(300,700,860,860,PI,2*PI);
  
}