var drops=[];
class drop
{
  constructor()
  {
    this.x=random(width);
    this.y=random(-800,-400);
    this.yspeed=random(2,10);
    this.xspeed=random(2,8);
    this.len=random(2,5);
  }
  fall()
  {
    this.y=this.y +this.yspeed;
    if(this.y>600)
    {
      this.y=random(-300,-400);
    }
    this.x=this.x+this.xspeed;
    if(this.x>600)
    {
      this.x=random(-300,-400);
    }
  }
  show(i)
  {
    colorMode(HSB);
    strokeWeight(4);
    stroke(200);
    ellipse(this.x,this.y,this.len,this.len);
  }
}
    
function setup() {
  //bg=loadImage("https://www.moonology.com/wp-content/uploads/2015/11/xmas2015.jpg");
  createCanvas(600,550);
  for(var i=0;i<200;i++)
  {
    drops[i]=new drop();
  }
  
}
function draw() {
   background(0);
   arc(300,850,1100,700,PI,2*PI);
   line(300,600,300,400);
   tree();
   translate(-100,-100);
   for(var i=0;i<200;i++)
  {
    drops[i].fall();
    drops[i].show(i);
  }
}
function tree()
{
  translate(300,450);
   branch(100);
}  

function branch(len)

{
	
line(0,0,0,-len);
	
translate(0,-len);

	
if(len>4)
	
{
push();
	 
rotate(7);
	 
branch(len*0.67);
		
pop();
		
push();
	 
rotate(-7);
	 
branch(len*0.67);
		
pop();
	
}

}
