var a=0;
var i=0;
function setup() {
  createCanvas(400, 400);
}

function draw() 
{
 background(0)
 stroke(255);
 flower();
}
	function flower()
	{
	translate(200,200);
	colorMode(RGB);
	strokeWeight(2);
	for(a=0;a<=30*PI;a+=0.01)
	{
		var r=150*cos(5/9*a);
		var x=r*cos(a);
		var y=r*sin(a);
		point(x,y);
	}
}